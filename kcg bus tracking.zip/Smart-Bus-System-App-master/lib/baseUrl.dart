// Local

String baseUrl = "http://192.168.18.44:8000/";

// String baseUrl = "https://smart-bus-pass.herokuapp.com/";
