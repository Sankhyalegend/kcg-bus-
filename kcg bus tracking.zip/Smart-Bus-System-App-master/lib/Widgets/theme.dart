import 'package:flutter/material.dart';

Color primaryColor = Color(0xff07688e);
Color secondaryColor = Color(0xff556677);
Color lightBlack = Color(0xff666666);
