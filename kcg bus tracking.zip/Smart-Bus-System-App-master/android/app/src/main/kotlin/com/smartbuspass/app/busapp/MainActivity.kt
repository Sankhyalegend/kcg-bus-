package com.smartbuspass.app.busapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
